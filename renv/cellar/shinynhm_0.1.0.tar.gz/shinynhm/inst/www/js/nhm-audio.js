(function () {
  "use strict";

  function formatTime(s) {
    if (!isFinite(s)) return "0:00";
    var m = Math.floor(s / 60);
    var sec = Math.floor(s % 60);
    return m + ":" + (sec < 10 ? "0" : "") + sec;
  }

  function initPlayer(el) {
    var src = el.getAttribute("data-src");
    var audio = new Audio(src);
    audio.preload = "metadata";

    var playBtn = el.querySelector(".nhm-audio-play");
    var seekBar = el.querySelector(".nhm-audio-seek");
    var seekFill = el.querySelector(".nhm-audio-seek-fill");
    var seekThumb = el.querySelector(".nhm-audio-seek-thumb");
    var curTime = el.querySelector(".nhm-audio-current");
    var durTime = el.querySelector(".nhm-audio-duration");
    var volBtn = el.querySelector(".nhm-audio-vol-btn");
    var volBar = el.querySelector(".nhm-audio-vol");
    var volFill = el.querySelector(".nhm-audio-vol-fill");

    audio.volume = 0.8;
    if (volFill) volFill.style.width = "80%";

    audio.addEventListener("loadedmetadata", function () {
      durTime.textContent = formatTime(audio.duration);
    });

    audio.addEventListener("timeupdate", function () {
      curTime.textContent = formatTime(audio.currentTime);
      if (audio.duration) {
        var pct = (audio.currentTime / audio.duration) * 100;
        seekFill.style.width = pct + "%";
        seekThumb.style.left = pct + "%";
      }
    });

    audio.addEventListener("ended", function () {
      playBtn.innerHTML = "&#9654;";
      playBtn.setAttribute("aria-label", "Play");
    });

    playBtn.addEventListener("click", function () {
      if (audio.paused) {
        audio.play();
        playBtn.innerHTML = "&#9646;&#9646;";
        playBtn.setAttribute("aria-label", "Pause");
      } else {
        audio.pause();
        playBtn.innerHTML = "&#9654;";
        playBtn.setAttribute("aria-label", "Play");
      }
    });

    function seekFromEvent(e) {
      var rect = seekBar.getBoundingClientRect();
      var pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
      audio.currentTime = pct * audio.duration;
    }

    var seeking = false;
    seekBar.addEventListener("mousedown", function (e) {
      seeking = true;
      seekFromEvent(e);
    });
    document.addEventListener("mousemove", function (e) {
      if (seeking) seekFromEvent(e);
    });
    document.addEventListener("mouseup", function () {
      seeking = false;
    });

    if (volBtn) {
      volBtn.addEventListener("click", function () {
        audio.muted = !audio.muted;
        volBtn.innerHTML = audio.muted ? "&#128263;" : "&#128265;";
        volBtn.setAttribute("aria-label", audio.muted ? "Unmute" : "Mute");
      });
    }

    if (volBar) {
      volBar.addEventListener("click", function (e) {
        var rect = volBar.getBoundingClientRect();
        var pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        audio.volume = pct;
        audio.muted = false;
        if (volFill) volFill.style.width = (pct * 100) + "%";
        if (volBtn) {
          volBtn.innerHTML = pct === 0 ? "&#128263;" : "&#128265;";
        }
      });
    }
  }

  // Initialise any player that appears (including Shiny re-renders)
  var observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (m) {
      m.addedNodes.forEach(function (node) {
        if (node.nodeType !== 1) return;
        if (node.classList && node.classList.contains("nhm-audio-player")) {
          initPlayer(node);
        }
        var children = node.querySelectorAll && node.querySelectorAll(".nhm-audio-player");
        if (children) {
          children.forEach(function (child) { initPlayer(child); });
        }
      });
    });
  });

  if (document.body) {
    observer.observe(document.body, { childList: true, subtree: true });
  } else {
    document.addEventListener("DOMContentLoaded", function () {
      observer.observe(document.body, { childList: true, subtree: true });
    });
  }

  // Init any already in the DOM
  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".nhm-audio-player").forEach(initPlayer);
  });
})();
